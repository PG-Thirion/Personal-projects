# Import necessary libraries
import tkinter as tk
import math

# Function to handle button clicks
def on_click(button_value):
    # Get the current text from the entry widget
    current_text = result_var.get()

    # Check the value of the clicked button
    if button_value == '=':
        try:
            # Evaluate the expression and set the result
            result = eval(current_text)
            result_var.set(result)
        except Exception as e:
            # Handle errors and display "Error" if any
            result_var.set("Error")
    elif button_value == 'C':
        # Clear the entry widget if 'C' button is clicked
        result_var.set("")
    elif button_value == 'π':
        # Append the value of pi to the current text
        result_var.set(current_text + str(math.pi))
    elif button_value == 'e':
        # Append the value of e to the current text
        result_var.set(current_text + str(math.e))
    elif button_value == 'sqrt':
        try:
            # Calculate the square root and set the result
            result = math.sqrt(float(current_text))
            result_var.set(result)
        except ValueError:
            # Handle errors and display "Error" if any
            result_var.set("Error")
    elif button_value == 'sin':
        # Calculate sine and set the result
        result = math.sin(math.radians(float(current_text)))
        result_var.set(result)
    elif button_value == 'cos':
        # Calculate cosine and set the result
        result = math.cos(math.radians(float(current_text)))
        result_var.set(result)
    elif button_value == 'tan':
        # Calculate tangent and set the result
        result = math.tan(math.radians(float(current_text)))
        result_var.set(result)
    else:
        # Append the clicked button value to the current text
        result_var.set(current_text + str(button_value))

# Create the main window
root = tk.Tk()
root.title("Scientific Calculator")

# Variable to hold the result
result_var = tk.StringVar()
result_var.set("")

# Entry widget to display the result
result_entry = tk.Entry(root, textvariable=result_var, font=('Helvetica', 16), justify='right', bd=10)
result_entry.grid(row=0, column=0, columnspan=6)

# Buttons layout
buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+',
    'C', 'π', 'e', 'sqrt',
    'sin', 'cos', 'tan'
]

# Initialize row and column values for grid layout
row_val = 1
col_val = 0

# Create and place buttons on the grid
for button in buttons:
    tk.Button(root, text=button, padx=10, pady=10, font=('Verdana', 14),
              command=lambda b=button: on_click(b)).grid(row=row_val, column=col_val)
    col_val += 1
    if col_val > 3:
        col_val = 0
        row_val += 1

# Start the main loop
root.mainloop()
