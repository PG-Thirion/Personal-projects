# Scientific Calculator with Tkinter

This is a simple scientific calculator implemented in Python using the Tkinter library for the graphical user interface. The calculator supports basic arithmetic operations, mathematical constants (π and e), and trigonometric functions (sin, cos, tan).

## Features

- Addition, subtraction, multiplication, and division.
- Mathematical constants π (pi) and e (Euler's number).
- Square root function.
- Trigonometric functions: sine, cosine, and tangent.
- Error handling for invalid mathematical expressions.

## Libraries Used

- **Tkinter**: Tkinter is the standard GUI toolkit for Python. It provides a set of tools to create graphical user interfaces.

- **math**: The math module in Python provides mathematical functions. In this calculator, it is used for basic arithmetic operations, as well as for trigonometric and square root calculations.

## How to Run

1. Make sure you have Python installed on your system.
2. Open a terminal or command prompt.
3. Navigate to the directory containing the script.
4. Run the script using the command: `python calculator.py`.

## Usage

- Press buttons for numbers (0-9), operators (+, -, *, /), and functions (sqrt, sin, cos, tan).
- 'C' button clears the display.
- 'π' button appends the value of pi to the current expression.
- 'e' button appends the value of Euler's number to the current expression.
- '=' button evaluates the expression.
- Errors are displayed as "Error" on the screen.

## Code Structure

- `calculator.py`: The main script containing the calculator implementation.
- `README.md`: This readme file explaining the project.

